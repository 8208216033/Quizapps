import React ,{useState, useEffect } from "react";
import "./App.css";
import { useDispatch, useSelector } from "react-redux";
const Pagination = (Props)=>{
     
    const storeQuestion = useSelector((state) => state.question.question);
    const [userAnswer, setUserAnswer] = useState("");
    const [fw_style, fw_setStyle] = useState("cont");
    const [ff_style, ff_setStyle] = useState("cont");
    const [questionId, setQuestionId] = useState(1);
    const [mode, setMode] = useState("insert");
    
    useEffect(()=>{
        setQuestionId(Props.quesId)
    },[Props.quesId])
    console.log("PAGINATION12===",questionId);
    return(
    <div>
        <div className={`${fw_style} ${ff_style}`}>
            <ul className="pagination text-center">
                <li
                    className={`${
                    questionId === 1 ? "page-item active" : "page-item"
                    } ${fw_style} ${ff_style}`}
                    onClick={() => {
                    Props.handleStartQuestion(1);
                    }}
                >
                    <a
                    className={`page-link ${fw_style} ${ff_style}`}
                    href="javascript:void(0)"
                    onClick={() => {
                        Props.handleStartQuestion(1);
                    }}
                    >
                    1
                    </a>
                </li>
                <li
                    className={`${
                    questionId === 2 ? "page-item active" : "page-item"
                    }`}
                >
                    <a
                    className={`page-link ${fw_style} ${ff_style}`}
                    href="javascript:void(0)"
                    onClick={() => {
                        Props.handleStartQuestion(2);
                    }}
                    >
                    2
                    </a>
                </li>
                <li
                    className={`${
                    questionId === 3 ? "page-item active" : "page-item"
                    }`}
                >
                    <a
                    className={`page-link ${fw_style} ${ff_style}`}
                    href="javascript:void(0)"
                    onClick={() => {
                        Props.handleStartQuestion(3);
                    }}
                    >
                    3
                    </a>
                </li>
                <li
                    className={`${
                    questionId === 4 ? "page-item active" : "page-item"
                    }`}
                >
                    <a
                    className={`page-link ${fw_style} ${ff_style}`}
                    href="javascript:void(0)"
                    onClick={() => {
                        Props.handleStartQuestion(4);
                    }}
                    >
                    4
                    </a>
                </li>
                <li
                    className={`${
                    questionId === 5 ? "page-item active" : "page-item"
                    }`}
                >
                    <a
                    className={`page-link ${fw_style} ${ff_style}`}
                    href="javascript:void(0)"
                    onClick={() => {
                        Props.handleStartQuestion(5);
                    }}
                    >
                    5
                    </a>
                </li>
            </ul>
        </div>
    </div>
)}
export default Pagination