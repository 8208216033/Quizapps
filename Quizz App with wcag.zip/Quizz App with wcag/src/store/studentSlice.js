import { createSlice } from '@reduxjs/toolkit';
//const initialState
  export const studentSlice = createSlice({
    name: 'student',
    initialState:{student:[]},
    reducers: {
      addStudent:(state,{payload})=>{
        state.student.push(payload)  ;
      },
      editAttempt:(state,action)=>{
         state.student.map((student)=>{
          if(student.studentId===1){
            student.availAttempt=action.payload.availAttempt
          }
       })
      }
    },
  })
  export const {addStudent,editAttempt} = studentSlice.actions
  export default studentSlice.reducer