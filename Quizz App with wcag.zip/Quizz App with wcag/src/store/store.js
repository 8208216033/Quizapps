import { configureStore } from "@reduxjs/toolkit";
import  questionReducer from './questionSlice';
import  studentReducer from './studentSlice';
import  resultReducer from './resultSlice';
export const store = configureStore({
    reducer:{
        question:questionReducer,
        student:studentReducer,
        result:resultReducer
    }
})