import { createSlice } from '@reduxjs/toolkit';
//const initialState
  export const questionSlice = createSlice({
    name: 'question',
    initialState:{question:[],student:[],totalTime:[],configuration:[]},
    reducers: {
      addQuestion:(state,{payload})=>{
        state.question.push(payload)  ;
      },

      
      addConfiguration:(state,{payload})=>{
        state.configuration.push(payload)  ;
      },
     
      editQuestion:(state,action)=>{
          state.question.map((ques)=>{
            if(ques.id===action.payload.qid){
              ques.obtained=action.payload.option
            }
         })
      },
     
      checkAnswerStatus:(state,action)=>{
        state.question.map((ques)=>{
          if(ques.id===action.payload.qid){
            ques.checkAnswer=action.payload.checkAnswer
          }
       })
      },
      submitTime:(state,{payload})=>{
        state.totalTime.push(payload);
      }
    },
  })
  export const { addQuestion,editQuestion,checkAnswerStatus,submitTime,addConfiguration,editAttempt} = questionSlice.actions
  export default questionSlice.reducer