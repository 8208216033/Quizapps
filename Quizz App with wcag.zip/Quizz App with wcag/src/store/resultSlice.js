import { createSlice } from '@reduxjs/toolkit';
  export const resultSlice = createSlice({
    name: 'result',
    initialState:{result:[]},
    reducers: {
      addResult:(state,{payload})=>{
        state.result.push(payload)  ;
      },
      editResult:(state,action)=>{
        state.result.map((res)=>{
          console.log("========",res)
          if(res.id === action.payload.id){
            
            res.TotalMarksObtain = action.payload.TotalMarksObtain
          }
       })
      }
    }
    
  })
  export const {addResult,editResult} = resultSlice.actions
  export default resultSlice.reducer