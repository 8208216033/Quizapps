import React, { useState, useEffect } from "react";
import "./App.css";
import Pagination from "./Pagination";
import LeftPanel from "./LeftPanel";
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "../node_modules/bootstrap/dist/js/bootstrap.min.js";
import "./switcher.scss";
import axios from "axios";
import Question from "./Question";
import { useDispatch, useSelector } from "react-redux";
import { checkAnswerStatus, submitTime } from "./store/questionSlice";
import { addResult } from "./store/resultSlice";
import { editAttempt } from "./store/studentSlice";
import { useNavigate } from "react-router-dom";
const Start = () => {
  const storeQuestion = useSelector((state) => state.question.question);
  const studentStoreData = useSelector((state) => state.student.student);
  const studentAttempt = studentStoreData[0].availAttempt;
  const configurationData = useSelector((state) => state.question.configuration[0]);
  const dispatch = useDispatch();
  const history = useNavigate();
  const [userAnswer, setUserAnswer] = useState("");
  const [checkAnswer, setCheckAnswer] = useState("");
  const [answerStatus, setAnswerStatus] = useState("");
  const [mode, setMode] = useState("insert");
  const [colorTheme, setColorTheme] = useState("theme-white");
  const [questionId, setQuestionId] = useState(1);
  const [question, setQuestion] = useState("");
  const [totalTime, setTotalTime] = useState("");
  const [minutes, setMinutes] = useState(59);
  const [seconds, setSeconds] = useState(60);
  const [isPaused, setPause] = useState(false);
  const currentElement = storeQuestion.find((o) => o.id === questionId);
  const [fw_option, fw_setoption] = useState("");
  const [fw_style, fw_setStyle] = useState("cont");
  const [ff_option, ff_setoption] = useState("");
  const [ff_style, ff_setStyle] = useState("cont");
  useEffect(()=>{
    setMinutes(configurationData.timelimit -1 )
  },[minutes])
  var myInterval;
  useEffect(() => {
    myInterval = setInterval(() => {
      if (!isPaused) {
        if (seconds >= 0) {
          setSeconds(seconds - 1);
        } else {
          setSeconds(60);
        }
        if (seconds === 0) {
          setMinutes(minutes - 1);
          setSeconds(59);
        }
      }
    }, 1000);
    return () => {
      clearInterval(myInterval);
    };
  });
  const pause = (e) => {
    e.preventDefault();
    setPause(true);
  };
  const play = (e) => {
    e.preventDefault();
    setPause(false);
  };
  useEffect(() => {
    const currentThemeColor = localStorage.getItem("theme-color");
    if (currentThemeColor) {
      setColorTheme(currentThemeColor);
    }
    const currentFontWeight = localStorage.getItem("font-weight");
        if (currentFontWeight) {
          fw_setStyle(currentFontWeight);
    }
    const currentFontFamily = localStorage.getItem("font-family");
        if (currentFontFamily) {
          ff_setStyle(currentFontFamily);
    }
  });
  useEffect(() => {
    if (questionId > 0) {
      const getQuestion = async () => {
        const url = "http://localhost:3333/questionairs/" + questionId;
        const rst = await axios.get(url);
        setQuestion(rst.data);
        setAnswerStatus("");
      };
      getQuestion();
    }
  }, [questionId]);
  const handleClick = (theme) => {
    setColorTheme(theme);
    localStorage.setItem("theme-color", theme);
  };
  const handleQuestion = () => {
    setQuestionId(questionId + 1);
    let obj = storeQuestion.find((o) => o.id === questionId + 1);
    setUserAnswer(obj.obtained);
    setMode("insert");
  };
  const handleBackQuestion = () => {
    setQuestionId(questionId - 1);
    let obj = storeQuestion.find((o) => o.id === questionId - 1);
    setUserAnswer(obj.obtained);
    setMode("update");
  };
  const checkAnswerFunc = () => {
    let obj = storeQuestion.find((o) => o.id === questionId);
    if (obj.checkAnswer === "") {
      dispatch(checkAnswerStatus({ qid: obj.id, checkAnswer: "yes" }));
    }else{
      dispatch(checkAnswerStatus({ qid: obj.id, checkAnswer: "no" }));
      setCheckAnswer('no')
    }
    if (obj.Answer !== obj.obtained) {
      setAnswerStatus("wrong");
    } else {
      setAnswerStatus("");
    }
  };
  const handleStartQuestion = (id) => {
    setQuestionId(id);
    let obj = storeQuestion.find((o) => o.id === id);
    setUserAnswer(obj.obtained);
    setMode("insert");
  };
  const handleQuestions = () => {
    clearInterval(myInterval);
    setTotalTime(minutes + ":" + seconds);
    dispatch(submitTime({ totalTime: minutes + ":" + seconds }));
    if(typeof(studentAttempt) !== 'undefined'){
      dispatch(editAttempt({studentId:1,availAttempt:parseInt(studentAttempt)-1}));
    }
    history("/result");
  };
  function handlefontWeight(e) {
    if (e.target.value === "Normal") {
      fw_setStyle("normal");
      localStorage.setItem("font-weight", "normal");
    }
    if (e.target.value === "Bold") {
      fw_setStyle("bold");
      localStorage.setItem("font-weight", "bold");
    }
    if (e.target.value === "Bolder") {
      fw_setStyle("bolder");
      localStorage.setItem("font-weight", "bolder");
    }
  }

  function handlefontFamily(e) {
    if (e.target.value === "Georgia") {
      ff_setStyle("Georgia");
      localStorage.setItem("font-family", "Georgia");
    }
    if (e.target.value === "Arial") {
      ff_setStyle("Arial");
      localStorage.setItem("font-family", "Arial");
    }
    if (e.target.value === "cursive") {
      ff_setStyle("cursive");
      localStorage.setItem("font-family", "cursive");
    }
  }
  return (
    <>
      <div className={`${fw_style} ${ff_style}`}>
        <div className={`App ${colorTheme}`}>
          <div className={`${fw_style} ${ff_style}`}>
          <div role="main" className="header flex-class">
            <div role="heading" tabIndex="0" className="col-lg-3 col-md-3 col-sm-3 col-xs-12 left-header">
              <h4>Quiz App</h4>
            </div>
            {questionId <= 5 ? (
              <div className="col-lg-9 col-md-9 col-sm-9 col-xs-12 right-header">
                <div role="button" className="text-resp">
                  <button
                  tabIndex="0"
                    className={`btn-nav-play-pause ${colorTheme} ${fw_style} ${ff_style}`}
                    onClick={play}
                  >
                    <i class="fa fa-play-circle" aria-hidden="true"></i>
                    &nbsp;Play
                  </button>
                  <button
                   tabIndex="0"
                    className={`btn-nav-play-pause ${colorTheme} ${fw_style} ${ff_style}`}
                    onClick={pause}
                  >
                    <i class="fa fa-pause-circle" aria-hidden="true"></i>
                    &nbsp;Pause
                  </button>
                  <span   tabIndex="0"className="total-time">
                    Total Time : {minutes}:
                    {seconds < 10 ? `0${seconds}` : seconds}
                  </span>
                  <button
                   tabIndex="0"
                    type="button"
                    className="btn-right-nav"
                    data-toggle="modal"
                    data-target="#exampleModal"
                  >
                    <p
                      className="sansserif"
                      style={{ background: "transparent" }}
                    >
                      &#8801;
                    </p>
                  </button>
                </div>
              </div>
            ) : (
              ""
            )}
          </div>
          </div>
          
          <div className="content">
            {questionId <= 5 ? (
              question !== "" ? (
                <Question data={question} mode={mode} userAnswer={userAnswer} checkAnswer={checkAnswer}/>
              ) : (
                ""
              )
            ) : (
              ""
            )}
          </div>
          
          {questionId <= 5 ? (
            <div role="contentinfo" className="card-footer footer">
              <div className="row">
                <div className="col-lg-4 col-md-4 col-sm-12 col-xs-12 check-answer-div">
                  {currentElement !== undefined ? (
                    currentElement.checkAnswer === "" ? (
                      <button
                      tabIndex="0"
                        className={`btn-nav ${colorTheme} ${fw_style} ${ff_style}`}
                        onClick={checkAnswerFunc}
                      >
                        Check Answer
                      </button>
                    ) : currentElement.checkAnswer === "yes" ? (
                      <button
                      tabIndex="0"
                        className={`btn-nav ${colorTheme} ${fw_style} ${ff_style}`}
                        onClick={checkAnswerFunc}
                      >
                        Check Answer
                      </button>
                    ) : (
                      <span  tabIndex="0" className="answer-status">
                        Check attempt limit exceeded!
                      </span>
                    )
                  ) : (
                    <button
                    tabIndex="0"
                      className={`btn-nav ${colorTheme} ${fw_style} ${ff_style}`}
                      onClick={checkAnswerFunc}
                    >
                      Check Answer
                    </button>
                  )}
                  {currentElement !== undefined ? (
                    currentElement.checkAnswer === "yes" ? (
                      <span  tabIndex="0" className="answer-status">{answerStatus}</span>
                    ) : (
                      ""
                    )
                  ) : (
                    ""
                  )}
                </div>
                <div className="col-lg-4 col-md-4 col-sm-12 col-xs-12 pagination-div">
                <Pagination quesId={questionId} handleStartQuestion={handleStartQuestion}/>
                
                  
                </div>
                <div role="button" className="col-lg-4 col-md-4 col-sm-12 col-xs-12 d-flex prev-next-div">
                  {questionId !== 1 ? (
                    <button
                    tabIndex="0"
                      className={`btn-nav btn-prev ${colorTheme} ${fw_style} ${ff_style}`}
                      onClick={handleBackQuestion}
                    >
                      Prev
                    </button>
                  ) : (
                    ""
                  )}
                  {questionId === 5 ? (
                    <button
                    tabIndex="0"
                      className={`btn-nav ${colorTheme} ${fw_style} ${ff_style}`}
                      onClick={handleQuestions}
                    >
                      Submit Quiz
                    </button>
                  ) : (
                    <button
                    tabIndex="0"
                      className={`btn-nav ${colorTheme} ${fw_style} ${ff_style}`}
                      onClick={handleQuestion}
                    >
                      Next
                    </button>
                  )}
                </div>
              </div>
            </div>
          ) : (
            ""
          )}
          {questionId <= 5 ? (
            <div
              className="modal left fade"
              id="exampleModal"
              tabindex="0"
              role="dialog"
              aria-labelledby="exampleModalLabel"
              aria-hidden="true"
            >
              <LeftPanel handlefontWeight={handlefontWeight} handlefontFamily={handlefontFamily} handleClick={handleClick}/>
            </div>
          ) : (
            ""
          )}
        </div>
      </div>
    </>
  );
};

export default Start;
