import React, { useEffect, useState } from "react";
import "./switcher.scss";
import "./App.css";
import "./Result.css";
import LeftPanel from "./LeftPanel";
import { useSelector, useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";
import { addResult, editResult } from "./store/resultSlice";

const Result = (Props) => {
  const history = useNavigate();
  const dispatch = useDispatch();
  const [fw_option, fw_setoption] = useState("");
  const [fw_style, fw_setStyle] = useState("cont");
  const [ff_option, ff_setoption] = useState("");
  const [ff_style, ff_setStyle] = useState("cont");
  let StudentAttempt = 0;
  let TotalAttempt = 0;
  let totalMarks = 0;
  let prevTotalMarksObtain = 0;
  let prevTotalMarks = 0;
  const questionData = useSelector((state) => state.question.question);
  const studentData = useSelector((state) => state.student.student[0]);
  const configurationData = useSelector((state) => state.question.configuration[0]);
  const resultData = useSelector((state) => state.result.result);
  const storeQuestion = useSelector((state) => state.question.question);
  const QuestionTime = useSelector((state) => state.question.totalTime[0].totalTime);
  
  if (Object.keys(resultData).length === 1) {
    let i = Object.keys(resultData).length - 1;
    prevTotalMarksObtain = resultData[i].TotalMarksObtain;
    prevTotalMarks = resultData[i].totalMarks;
  }
  if (configurationData !== undefined) {
    TotalAttempt = configurationData.attempt;
    totalMarks = configurationData.questions * configurationData.marks;
  }
  if (studentData !== undefined) {
    StudentAttempt = studentData.availAttempt;
  }
  const [colorTheme, setColorTheme] = useState("theme-white");
  useEffect(() => {
    const currentThemeColor = localStorage.getItem("theme-color");
    if (currentThemeColor) {
      setColorTheme(currentThemeColor);
    }
    const currentFontWeight = localStorage.getItem("font-weight");
    if (currentFontWeight) {
      fw_setStyle(currentFontWeight);
    }
    const currentFontFamily = localStorage.getItem("font-family");
    if (currentFontFamily) {
      ff_setStyle(currentFontFamily);
    }
  });

  const handleClick = (theme) => {
    setColorTheme(theme);
    localStorage.setItem("theme-color", theme);
  };

  if (storeQuestion.length === 0) {
    history("/");
  }
  function handlefontWeight(e) {
    fw_setoption(e.target.value);
    e.preventDefault();
    if (e.target.value === "Normal") {
      fw_setStyle("normal");
      localStorage.setItem("font-weight", "normal");
    }
    if (e.target.value === "Bold") {
      fw_setStyle("bold");
      localStorage.setItem("font-weight", "bold");
    }
    if (e.target.value === "Bolder") {
      fw_setStyle("bolder");
      localStorage.setItem("font-weight", "bolder");
    }
  }

  function handlefontFamily(e) {
    console.log(e.target.value);
    ff_setoption(e.target.value);
    e.preventDefault();
    if (e.target.value === "Georgia") {
      ff_setStyle("Georgia");
      localStorage.setItem("font-family", "Georgia");
    }
    if (e.target.value === "Arial") {
      ff_setStyle("Arial");
      localStorage.setItem("font-family", "Arial");
    }
    if (e.target.value === "cursive") {
      ff_setStyle("cursive");
      localStorage.setItem("font-family", "cursive");
    }
  }

  let TotalMarksObtain = 0;
  const calculateTotalMark = questionData.map((items) => {
    if (items.Answer === items.obtained) {
      TotalMarksObtain = TotalMarksObtain + parseInt(configurationData.marks);
    }
    return TotalMarksObtain;
  });
  const tryAgain = () => {
    if (Object.keys(resultData).length === 0) {
      dispatch(
        addResult({
          id: 1,
          totalMarks: totalMarks,
          TotalMarksObtain: TotalMarksObtain,
        })
      );
    } else {
      dispatch(
        editResult({
          id: 1,
          totalMarks: totalMarks,
          TotalMarksObtain: TotalMarksObtain,
        })
      );
    }
    history("/start");
  };

  return (
    <>
      <div className={`${fw_style} ${ff_style}`}>
        <div className={`App ${colorTheme}`}>
          <div className="header d-flex">
            <div role="header" className="col-sm-6">
              <h4 tabIndex="0">Quiz App</h4>
            </div>
            <div className="col-sm-6">
              <button
              tabIndex="0"
                type="button"
                className="btn-right-nav"
                data-toggle="modal"
                data-target="#exampleModal"
              >
                <p className="sansserif" style={{ background: "transparent" }}>
                  &#8801;
                </p>
              </button>
            </div>
          </div>
          {
            <div className="content pt-60">
              <div className="card-body content-box">
                <p className="card-text">
                  <table className="table table-bordered">
                    <tr>
                      <td colSpan={"2"} className="text-center">
                        <h4 tabIndex="0" className={`${fw_style} ${ff_style} txt-black`}>
                          Congratulations! You have completed your exam!
                        </h4>
                      </td>
                    </tr>
                  </table>
                  <div className="col-sm-12 pdr-0">
                    <div className="row justify-content-center">
                        <div className="box">
                          <div role="header" tabIndex="0" className="div-header"> Current Assessment:</div>
                          <p tabIndex="0" className="pleft-4">
                            Score: {TotalMarksObtain}/{totalMarks}{" "}
                          </p>
                          <button
                          tabIndex="0"
                            className={`${fw_style} ${ff_style} btn btn-result w-100`}
                          >
                            View Details
                          </button>
                        </div>
                        {Object.keys(resultData).length !== 0 ? (
                          <div className="box">
                            <div tabIndex="0" className="div-header">
                              {" "}
                              Previous Assessment:{" "}
                            </div>
                            <p tabIndex="0" className="pleft-4">
                              Score: {prevTotalMarksObtain}/{prevTotalMarks}{" "}
                            </p>
                            <button
                            tabIndex="0"
                              className={`${fw_style} ${ff_style} btn btn-result w-100`}
                            >
                              View Details
                            </button>
                          </div>
                        ) : (
                          ""
                          )}
                      </div>

                        <div className="row">
                        <div className="col">
                        {StudentAttempt !== undefined &&
                        TotalAttempt !== undefined ? (
                          <div tabIndex="0" role="generic" className="pt-3 t-right">
                            Total Number of Attempts Remaining: {StudentAttempt}/{TotalAttempt}
                          </div>
                        ) : (
                          ""
                        )}
                          </div>
                          <div className="col">
                          {StudentAttempt !== 0 ? (
                          <button
                          tabIndex="0"
                            className={`${fw_style} ${ff_style} btn btn-result`}
                            onClick={tryAgain}
                          >
                            Retry Assessment
                          </button>
                        ) : (
                          <span tabIndex="0" style={{ "color": "red","display":"flex","marginTop":"15px" }}>
                            You have exhausted all attempts!
                          </span>
                        )}
                          </div>
                      
                          
                      </div>
                    
                  </div>
                </p>

                <table tabIndex="0" className="table table-bordered result-table-header d-none">
                  <thead>
                    <th>Q.No.</th>
                    <th>Question</th>
                    <th>Result</th>
                  </thead>
                  <tbody>
                    {storeQuestion.map((Question) => (
                      <>
                        <tr>
                          <td className="text-center">{Question.id}</td>
                          <td>{Question.question}</td>
                          <td className="text-center">
                            <span
                              style={{
                                color:
                                  Question.Answer === Question.obtained
                                    ? "green"
                                    : "red",
                              }}
                            >
                              <b>
                                {Question.Answer === Question.obtained ? (
                                  <i class="fa fa-check"></i>
                                ) : (
                                  <i class="fa fa-times"></i>
                                )}
                              </b>
                            </span>
                          </td>
                        </tr>
                      </>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          }
          <div
            className="modal left fade"
            id="exampleModal"
            tabindex="0"
            role="dialog"
            aria-labelledby="exampleModalLabel"
            aria-hidden="true"
          >
            <LeftPanel handlefontWeight={handlefontWeight} handlefontFamily={handlefontFamily} handleClick={handleClick}/>
          </div>
        </div>
      </div>
    </>
  );
};
export default Result;
