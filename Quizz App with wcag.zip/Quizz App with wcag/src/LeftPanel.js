import React,{useState,useEffect} from "react";
const LeftPanel = (Props)=>{
    const [colorTheme, setColorTheme] = useState("theme-white");
    const [fw_style, fw_setStyle] = useState("cont");
    const [ff_style, ff_setStyle] = useState("cont");
    useEffect(() => {
      const currentThemeColor = localStorage.getItem("theme-color");
      if (currentThemeColor) {
        setColorTheme(currentThemeColor);
      }
      const currentFontWeight = localStorage.getItem("font-weight");
      if (currentFontWeight) {
        fw_setStyle(currentFontWeight);
      }
      const currentFontFamily = localStorage.getItem("font-family");
      if (currentFontFamily) {
        ff_setStyle(currentFontFamily);
      }
    }); 
    return(
        <div className="modal-dialog" role="document" >
            <div className={`App modal-content modal-right ${colorTheme} ${fw_style} ${ff_style}`}>
                <div className="modal-body">
                    <div className="nav flex-sm-column flex-row">
                      <label tabIndex="0"  for="Font weight">Font Weight:</label>
                      <select 
                      className="form-control sel-nav" 
                      id="" 
                      name=""
                      onChange={Props.handlefontWeight}
                      >
                        <option>Select</option>
                        <option>Normal</option>
                        <option>Bold</option>
                        
                      </select>

                      <label tabIndex="0" for="Font family">Font-Family:</label>
                      <select 
                      className="form-control sel-nav"
                      id=""
                      name=""
                      onChange={Props.handlefontFamily}
                      >
                        <option>Select</option>
                        <option>Georgia</option>
                        <option>Arial</option>
                        <option>cursive</option>
                      </select>

                      <label tabIndex="0" for="Theme">Theme:</label>
                      <div  role="toolbar" aria-orientation="horizontal" className="theme-options">
                        <div
                          id="theme-white"
                          onClick={() => Props.handleClick("theme-white")}
                          className="active"
                          tabIndex="0"
                          role="button"
                        ></div>
                        <div
                          id="theme-blue"
                          onClick={() => Props.handleClick("theme-blue")}
                          className="active"
                          tabIndex="0"
                          role="button"
                        ></div>
                        <div
                          id="theme-orange"
                          onClick={() => Props.handleClick("theme-orange")}
                          className="active"
                          tabIndex="0"
                          role="button"
                        ></div>
                        <div
                          id="theme-purple"
                          onClick={() => Props.handleClick("theme-purple")}
                          className="active"
                          tabIndex="0"
                          role="button"
                        ></div>
                        <div
                          id="theme-green"
                          onClick={() => Props.handleClick("theme-green")}
                          className="active"
                          tabIndex="0"
                          role="button"
                        ></div>
                        <div
                          id="theme-black"
                          onClick={() => Props.handleClick("theme-black")}
                          className="active"
                          tabIndex="0"
                          role="button"
                        ></div>
                      </div>
                    </div>
                  </div>
                  <div className="modal-footer">
                    <button
                      type="button"
                      className="btn btn-footer"
                      data-dismiss="modal"
                    >
                      Close
                    </button>
                  </div>
                </div>
              </div>
)}
export default LeftPanel;