import React,{ useEffect, useState } from 'react';
import "./App.css";
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/js/bootstrap.min";
import { useSelector,useDispatch } from 'react-redux';
import {addQuestion,editQuestion} from './store/questionSlice';
const Question = (Props)=>{
  console.log("Props",Props);
 const dispatch = useDispatch();
 const storeQuestion = useSelector((state)=>state.question.question);
 const [options,setOption]=useState('');
 const [editOptions,setEditOption]=useState('');
 const [quesCheckAnswer, setQuesCheckAnswer]=useState('');

  useEffect(()=>{
   setQuesCheckAnswer('')
  },[Props.data.id])
  
  useEffect(()=>{
    if(Props.mode === "update"){
      setEditOption(Props.userAnswer)
    }else{
      setOption(Props.userAnswer)
    }
  },[Props.userAnswer])

  useEffect(()=>{
    if(storeQuestion.length>0){
      let obj = storeQuestion.find((o) => o.id === Props.data.id);
      if(obj!==undefined){
        setQuesCheckAnswer(obj.checkAnswer)
      }
    }
  },[options])
  const handleOption =(e)=>{
    setOption(e.target.value)
    if(storeQuestion.length===0){
        Props.data.obtained = e.target.value;
        dispatch(addQuestion(Props.data))
    }else{
      let obj = storeQuestion.find(o => o.id === Props.data.id);
      if(obj===undefined){
          Props.data.obtained = e.target.value;
          dispatch(addQuestion(Props.data))
      }else{
          dispatch(editQuestion({qid:obj.id,option:e.target.value}))
          setOption(e.target.value);
          console.log('edit');
          setEditOption(e.target.value)
          
      } 
    }
  } 
    return( 
     <>
     {
      (Props.data!=='' || Props.data!=='undefined')?
      <div role="main" className="card-body content-box">
      <h5 tabIndex="0" className="card-title">
        <span>{Props.data.question}</span>
        
      </h5>
      <p className="card-text">
        <form action="/action_page.php">
          <div role="radio" className="form-check form-option-block mb-2">
            <input 
            tabIndex="0"
            type="radio" 
            id="html" 
            name="fav_language" 
            value={Props.data.options[0].option1} 
            checked={
              (Props.mode==="update")?
                editOptions===Props.data.options[0].option1
              :
                options===Props.data.options[0].option1
            }
            disabled={(quesCheckAnswer === 'no')?true:false}
              
            onChange={handleOption}/>
            <label for="html" className='label-class'>{Props.data.options[0].option1}</label>
          </div>
          <div role="radio" className="form-check form-option-block mb-2">
            <input 
            tabIndex="0"
            type="radio" 
            id="css" 
            name="fav_language" 
            value={Props.data.options[0].option2} 
            checked={
              (Props.mode==="update")?
                  editOptions===Props.data.options[0].option2
              :
                  options===Props.data.options[0].option2
            }
            disabled={(quesCheckAnswer === 'no')?true:false}
            onChange={handleOption} />
            <label for="css" className='label-class'>{Props.data.options[0].option2}</label>
          </div>
          <div role="radio" className="form-check form-option-block mb-2">
            <input type="radio"
           
            id="javascript" 
            name="fav_language" 
            value={Props.data.options[0].option3} 
            checked={
              (Props.mode==="update")?
                editOptions===Props.data.options[0].option3
              :
                options===Props.data.options[0].option3
            }
            disabled={(quesCheckAnswer === 'no')?true:false}
            onChange={handleOption} />
            <label for="javascript" className='label-class'>{Props.data.options[0].option3}</label>
          </div>
          <div role="radio" className="form-check form-option-block mb-2">
            <input 
            type="radio"  
            tabIndex="0"
            id="Bootstrap"  
            name="fav_language" 
            value={Props.data.options[0].option4} 
            checked={
              (Props.mode==="update")?
                editOptions===Props.data.options[0].option4
              :
                options===Props.data.options[0].option4
            }
            disabled={(quesCheckAnswer === 'no')?true:false}
            onChange={handleOption}  />
            <label for="Bootstrap" className='label-class'>{Props.data.options[0].option4}</label>
          </div>
        </form>
      </p>
    </div>
      :''}   
        
        </>
    )}
    export default Question;