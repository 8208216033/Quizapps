import React, { useEffect, useState } from "react";
import "./switcher.scss";
import "./App.css";
import { useNavigate } from "react-router-dom";
import "./Home.css";
import  axios  from "axios";
import { useDispatch, useSelector } from "react-redux";
import {addConfiguration } from "./store/questionSlice";
const Home = () => {
  const history = useNavigate();
  const storeConfiguration = useSelector((state) => state.question.configuration);
  const dispatch = useDispatch();
  const [colorTheme, setColorTheme] = useState("theme-white");
  const [fw_option, fw_setoption] = useState("");
  const [fw_style, fw_setStyle] = useState("cont");
  const [ff_option, ff_setoption] = useState("");
  const [ff_style, ff_setStyle] = useState("cont");
  useEffect(() => {
    const currentThemeColor = localStorage.getItem("theme-color");
    if (currentThemeColor) {
      setColorTheme(currentThemeColor);
    }
    const currentFontWeight = localStorage.getItem("font-weight");
    if (currentFontWeight) {
      fw_setStyle(currentFontWeight);
    }
    const currentFontFamily = localStorage.getItem("font-family");
    if (currentFontFamily) {
      ff_setStyle(currentFontFamily);
    }
  });

  const handleClick = (theme) => {
    setColorTheme(theme);
    localStorage.setItem("theme-color", theme);
  };

  const start = () => {
    history("/start");
  };

  function handlefontWeight(e) {
    fw_setoption(e.target.value);
    e.preventDefault();
    if (e.target.value === "Normal") {
      fw_setStyle("normal");
      localStorage.setItem("font-weight", "normal");
    }
    if (e.target.value === "Bold") {
      fw_setStyle("bold");
      localStorage.setItem("font-weight", "bold");
    }
    if (e.target.value === "Bolder") {
      fw_setStyle("bolder");
      localStorage.setItem("font-weight", "bolder");
    }
  }

  function handlefontFamily(e) {
    console.log(e.target.value);
    ff_setoption(e.target.value);
    e.preventDefault();
    if (e.target.value === "Georgia") {
      ff_setStyle("Georgia");
      localStorage.setItem("font-family", "Georgia");
    }
    if (e.target.value === "Arial") {
      ff_setStyle("Arial");
      localStorage.setItem("font-family", "Arial");
    }
    if (e.target.value === "cursive") {
      ff_setStyle("cursive");
      localStorage.setItem("font-family", "cursive");
    }
  }
  return (
    <>
      <div className={`${fw_style} ${ff_style}`}>
        <div 
          className={`App ${colorTheme}`}
          style={{ overflow: "hidden!important" }}
        >
          <div className="header d-flex">
            <div role="main" className="col-sm-6">
              <h4  tabIndex="0" >Quiz App</h4>
            </div>
            <div role="button" className="col-sm-6">
              <button
               tabIndex="0" 
                type="button"
                className="btn-right-nav"
                data-toggle="modal"
                data-target="#exampleModal"
              >
                <p  tabIndex="0"  className="sansserif" style={{ background: "transparent" }}>
                  &#8801;
                </p>
              </button>
            </div>
          </div>
          <div role="heading" className="center-div">
            <h2  tabIndex="0"  className="instruction-h1">Assessment</h2>
            <div role="term"className="instruction-header">
              <table className="instruction-table">
                <thead>
                  <tr>
                    <th  tabIndex="0"  scope="col">Date</th>
                    <th  tabIndex="0"  scope="col">Time</th>
                    <th  tabIndex="0"  scope="col">Score</th>
                    <th  tabIndex="0"  scope="col">Questions</th>
                    <th  tabIndex="0"  scope="col">Time</th>
                    <th  tabIndex="0"  scope="col">Attempts</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td  tabIndex="0"  data-label="Date">Jul 12,2017</td>
                    <td  tabIndex="0"  data-label="Time">11.17 PM</td>
                    <td  tabIndex="0"  data-label="Points">{storeConfiguration[0].marks}</td>
                    <td  tabIndex="0"  data-label="Questions">{storeConfiguration[0].questions}</td>
                    <td  tabIndex="0"  data-label="Time">{storeConfiguration[0].timelimit} mins</td>
                    <td  tabIndex="0"  data-label="Attempts">{storeConfiguration[0].attempt}</td>
                  </tr>
                </tbody>
              </table>
              {/* <div className="row">
              <div className="col">
                <b>Date</b> Jul 12,2017
              </div>
              <div className="col">
                <b>Time</b> 11.17 PM
              </div>
              <div className="col">
                <b>Points</b> 10
              </div>
              <div className="col">
                <b>Questions</b> 10
              </div>
              <div className="col">
                <b>Time</b> 60 mins
              </div>
              <div className="col">
                <b>Attempts</b> 3
              </div>
            </div> */}
            </div>
            <div role="article" className="instructions-div">
              <h2  tabIndex="0" >Instructions</h2>
              <p  tabIndex="0"  className="ml-15 text-justify">
                <ul>
                  <li>This quiz consists of 10 multiple-choice questions.</li>
                  <li>
                    To be successful with the weekly quizzes, it’s important to
                    thoroughly read chapter 5 in the textbook.
                  </li>
                </ul>
              </p>
              <table class="table table-bordered result-table-header">
                <tbody>
                  <tr>
                    <th  tabIndex="0" >Attempts</th>
                    <td  tabIndex="0" >
                      You will have three attempts for this quiz with your
                      highest score being recorded in the grade book.
                    </td>
                  </tr>
                  <tr>
                    <th  tabIndex="0" >Timing</th>
                    <td  tabIndex="0" >
                      You will need to complete each of your attempts in one
                      sitting, as you are allotted 30 minutes to complete each
                      attempt.
                    </td>
                  </tr>
                  <tr>
                    <th  tabIndex="0" >Answers</th>
                    <td  tabIndex="0" >
                      You may review your answer-choices and compare them to the
                      correct answers after your final attempt.
                    </td>
                  </tr>
                </tbody>
              </table>

              <p  tabIndex="0"  style={{ paddingTop: "10px" }}>
                To start, click the <b>"Take the Quiz"</b> button. When
                finished, click the <b>"Submit Quiz"</b> button.
              </p>

              <div role="button" className="text-center">
                <button  tabIndex="0"  className="btn btn-assessment" onClick={start}>
                  Take the Quiz
                </button>
              </div>
            </div>
          </div>
          {/* <div className="footer">
        footer
        </div> */}
          <div
            className="modal left fade"
            id="exampleModal"
            tabindex="0"
            role="dialog"
            aria-labelledby="exampleModalLabel"
            aria-hidden="true"
          >
            <div className="modal-dialog" role="document">
              <div
                className={`App modal-content modal-right ${colorTheme} ${fw_style} ${ff_style}`}
              >
                <div className="modal-body">
                  <div className="nav flex-sm-column flex-row">
                    <label  tabIndex="0"  for="font weight">Font Weight:</label>
                    <select
                      className="form-control sel-nav"
                      id=""
                      name=""
                      onChange={handlefontWeight}
                    >
                      <option>Select</option>
                      <option>Normal</option>
                      <option>Bold</option>
                      {/* <option>Bolder</option> */}
                    </select>

                    <label  tabIndex="0"  for="font family">Font-Family:</label>
                    <select
                      className="form-control sel-nav"
                      id=""
                      name=""
                      onChange={handlefontFamily}
                    >
                      <option>Select</option>
                      <option>Georgia</option>
                      <option>Arial</option>
                      <option>cursive</option>
                    </select>

                    <label  tabIndex="0"  for="Theme">Theme:</label>
                    <div className="theme-options">
                      <div
                        id="theme-white"
                        onClick={() => handleClick("theme-white")}
                        className="active"
                        tabIndex="0" 
                        role="button"
                      ></div>
                      <div
                        id="theme-blue"
                        onClick={() => handleClick("theme-blue")}
                        className="active"
                        tabIndex="0" 
                        role="button"
                      ></div>
                      <div
                        id="theme-orange"
                        onClick={() => handleClick("theme-orange")}
                        className="active"
                        tabIndex="0" 
                        role="button"
                      ></div>
                      <div
                        id="theme-purple"
                        onClick={() => handleClick("theme-purple")}
                        className="active"
                        tabIndex="0" 
                        role="button"
                      ></div>
                      <div
                        id="theme-green"
                        onClick={() => handleClick("theme-green")}
                        className="active"
                        tabIndex="0" 
                        role="button"
                      ></div>
                      <div
                        id="theme-black"
                        onClick={() => handleClick("theme-black")}
                        className="active"
                        tabIndex="0" 
                        role="button"
                      ></div>
                    </div>
                  </div>
                </div>
                <div className="modal-footer">
                  <button
                    type="button"
                    className="btn btn-footer"
                    data-dismiss="modal"
                  >
                    Close
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Home;
