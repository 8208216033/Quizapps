import React,{useState,useEffect} from 'react';
import "./switcher.scss";
import "./App.css";
import "./registration.css";
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "../node_modules/bootstrap/dist/js/bootstrap.min.js";
import { useNavigate } from "react-router-dom";
import  axios  from "axios";
const Registration = ()=>{
    const history = useNavigate();
    const [colorTheme, setColorTheme] = useState("theme-white");
    const initialValues={studentName:"",studentClass:"",studentEmail:""}
    const [formValues,setFormValues]=useState(initialValues);
    useEffect(() => {
        const currentThemeColor = localStorage.getItem("theme-color");
        if (currentThemeColor) {
        setColorTheme(currentThemeColor);
        }
    });
    const handleClick = (theme) => {
        setColorTheme(theme);
        localStorage.setItem("theme-color", theme);
    };
    
    const handleChange = (e)=>{
        const{name,value}=e.target;
        setFormValues({...formValues, [name]: value});
        console.log("hello",formValues);
    }
    const formSubmit = async(e)=>{
        e.preventDefault();
        console.log("sdsdsds=====",formValues)
        await axios.post("http://localhost:3333/users",formValues)
        history("/home");
    }
return(
    <>
        <div className={`App ${colorTheme}`} style={{"overflow":"hidden!important"}}>
           <div className="header d-flex">
                <div className="col-sm-6">
                    <h4>Quiz App</h4>
                </div>
                <div className="col-sm-6">
                    <button
                    type="button"
                    className="btn-right-nav"
                    data-toggle="modal"
                    data-target="#exampleModal"
                    >
                    <p className="sansserif" style={{ background: "transparent" }}>
                        &#8801;
                    </p>
                    </button>
                </div>
            </div>
                <div className="center-div" >
                    <div className='leftContainer'>
                        <h2>Registration Form</h2>
                        <form onSubmit={formSubmit}>
                            <div className="form-group">
                                <label for="studentName">Student Name</label>
                                <input type="text" className='form-control'  name="studentName" value={formValues.studentName} onChange={handleChange} required  aria-required="true" aria-autocomplete="both" tabindex="0"/>
                            </div> 
                            <div className="form-group">
                                <label for="studentClass">Student Class</label>
                                <input type="text" className='form-control'  name="studentClass" value={formValues.studentClass} onChange={handleChange} required tabindex="0"/>
                            </div>   
                            <div className="form-group">
                                <label for="studentEmail">Email address</label>
                                <input type="email" className='form-control'  name="studentEmail" value={formValues.studentEmail} onChange={handleChange} autoComplete='off' required tabindex="0"/>
                            </div>
                            <div className="form-group">
                                <label for="studentPhone">Student Phone</label>
                                <input type="tel" className='form-control'  name="studentPhone" value={formValues.studentPhone} onChange={handleChange} autoComplete='off' required tabindex="0"/>
                            </div>
                            <div className="form-group">
                                <label for="dateOfBirth">Date of Birth</label>
                                <input type="text" className='form-control'  name="dateOfBirth" value={formValues.dateOfBirth} onChange={handleChange} autoComplete='off' required tabindex="0"/><span>Ex. dd-mm-yyyy</span>
                            </div>
                            <div className="form-group">
                                <label for="userName">UserName</label>
                                <input type="text" className='form-control'  name="userName" value={formValues.userName} onChange={handleChange} autoComplete='off' required tabindex="0"/>
                            </div>
                            <div className="form-group">
                                <label for="password">Password</label>
                                <input type="password" className='form-control'  name="password" value={formValues.password} onChange={handleChange} autoComplete='off' required tabindex="0"/>
                            </div>
                            
                            <div className="form-group">
                                <button type="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
            <div
          className="modal left fade"
          id="exampleModal"
          tabindex=""
          role="dialog"
          aria-labelledby="exampleModalLabel"
          aria-hidden="true"
        >
            <div className="modal-dialog" role="document">
                <div className={`App modal-content modal-right ${colorTheme}`}>
                <div className="modal-body">
                    <div className="nav flex-sm-column flex-row">
                    {/* <label for="">Font Size:</label>
                    <select className="form-control sel-nav" id="" name="">
                        <option>Select</option>
                        <option>16px</option>
                        <option>18px</option>
                        <option>20px</option>
                    </select> */}

                    <label for="">Font Weight:</label>
                    <select className="form-control sel-nav" id="" name="">
                        <option>Select</option>
                        <option>Normal</option>
                        <option>Bold</option>
                        {/* <option>Bolder</option> */}
                    </select>

                    <label for="">Font-Family:</label>
                    <select className="form-control sel-nav" id="" name="">
                        <option>Select</option>
                        <option>Verdana</option>
                        <option>Arial</option>
                        <option>Mulish</option>
                    </select>

                    <label for="">Theme:</label>
                    <div className="theme-options">
                        <div
                        id="theme-white"
                        onClick={() => handleClick("theme-white")}
                        className="active"
                        ></div>
                        <div
                        id="theme-blue"
                        onClick={() => handleClick("theme-blue")}
                        className="active"
                        ></div>
                        <div
                        id="theme-orange"
                        onClick={() => handleClick("theme-orange")}
                        className="active"
                        ></div>
                        <div
                        id="theme-purple"
                        onClick={() => handleClick("theme-purple")}
                        className="active"
                        ></div>
                        <div
                        id="theme-green"
                        onClick={() => handleClick("theme-green")}
                        className="active"
                        ></div>
                        <div
                        id="theme-black"
                        onClick={() => handleClick("theme-black")}
                        className="active"
                        ></div>
                    </div>
                    </div>
                </div>
                <div className="modal-footer">
                    <button
                    type="button"
                    className="btn btn-footer"
                    data-dismiss="modal"
                    >
                    Close
                    </button>
                </div>
                </div>
            </div>
            </div>
    </div>           
        </>
    );

}
export default Registration;