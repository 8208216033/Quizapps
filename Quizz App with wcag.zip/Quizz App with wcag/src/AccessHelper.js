import React, { useState, useEffect } from "react";
import "./App.css";
import "./AccessHelper.css";
import LeftPanel from "./LeftPanel";
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "../node_modules/bootstrap/dist/js/bootstrap.min.js";
import "./switcher.scss";
import { useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import {addConfiguration} from "./store/questionSlice";
import { addStudent } from "./store/studentSlice";
import {Container,Row,Col} from 'react-bootstrap'
const AccessHelper = () => {
  const history = useNavigate();
    const dispatch = useDispatch();
    const initialValues={orgname:"",class:"",subject:"",type:"",questions:"",attempt:"",poolid:"",overWrite:"",marks:"",nagativeMarking:"",timelimit:"",passingThreashold:""};
  const [formValues, setFormValues] = useState(initialValues);
  const [colorTheme, setColorTheme] = useState("theme-white");
  const [fw_option, fw_setoption] = useState("");
  const [fw_style, fw_setStyle] = useState("cont");
  const [ff_option, ff_setoption] = useState("");
  const [ff_style, ff_setStyle] = useState("cont");
  useEffect(() => {
    const currentThemeColor = localStorage.getItem("theme-color");
    if (currentThemeColor) {
      setColorTheme(currentThemeColor);
    }
    const currentFontWeight = localStorage.getItem("font-weight");
    if (currentFontWeight) {
      fw_setStyle(currentFontWeight);
    }
    const currentFontFamily = localStorage.getItem("font-family");
    if (currentFontFamily) {
      ff_setStyle(currentFontFamily);
    }
  });
  
  
  function handlefontWeight(e) {
    fw_setoption(e.target.value);
    e.preventDefault();
    if (e.target.value === "Normal") {
      fw_setStyle("normal");
      localStorage.setItem("font-weight", "normal");
    }
    if (e.target.value === "Bold") {
      fw_setStyle("bold");
      localStorage.setItem("font-weight", "bold");
    }
    if (e.target.value === "Bolder") {
      fw_setStyle("bolder");
      localStorage.setItem("font-weight", "bolder");
    }
  }
  function handlefontFamily(e) {
    console.log(e.target.value);
    ff_setoption(e.target.value);
    e.preventDefault();
    if (e.target.value === "Georgia") {
      ff_setStyle("Georgia");
      localStorage.setItem("font-family", "Georgia");
    }
    if (e.target.value === "Arial") {
      ff_setStyle("Arial");
      localStorage.setItem("font-family", "Arial");
    }
    if (e.target.value === "cursive") {
      ff_setStyle("cursive");
      localStorage.setItem("font-family", "cursive");
    }
  }
  const handleClick = (theme) => {
    setColorTheme(theme);
    localStorage.setItem("theme-color", theme);
  };
  const handleChange=(e)=>{
    const{name,value}=e.target;
    setFormValues({...formValues, [name]: value});
}
const handleOnSubmit=(e)=>{

    e.preventDefault();
    console.log("===formValues====",formValues.attempt);
    dispatch(addStudent({"studentId":1,"name":"Nirvikar","email":'test@test.com',"availAttempt":formValues.attempt}));
    dispatch(addConfiguration({...formValues,"studentId":1}));
    history("/home");
}
  return (
    <>
    <div className={`${fw_style} ${ff_style}`}>
    <div
        className={`App ${colorTheme}`}
        style={{ overflow: "hidden!important" }}
      >
        <div className="header d-flex">
          <div role="header" className="col-sm-6">
            <h4 tabIndex="0" className={`${fw_style} ${ff_style}`}>Assessment Helper Configuration</h4>
          </div>
          <div role="button" className="col-sm-6">
            <button
            tabIndex="0"
              type="button"
              className="btn-right-nav"
              data-toggle="modal"
              data-target="#exampleModal"
            >
              <p className="sansserif" style={{ background: "transparent" }}>
                &#8801;
              </p>
            </button>
          </div>
        </div>
        <div className="center-div">
        <form onSubmit={handleOnSubmit}>
          <div>
              <Container>
                <Row>
                  <Col tabIndex="0" sm={6}>
                    <div class="cols-label">
                        <label for="orgname" className="pt-1">Organization Name</label>
                    </div>
                    <div >
                      <select name="orgname" className="form-control" onChange={handleChange} >
                        <option value="">Select Organization Name</option>
                        <option value="CWNG">CWNG</option>
                        
                      </select>
                    </div>
                  </Col>
                  <Col tabIndex="0" sm={6}>
                    <label  for="class" className="pt-1">Class</label>
                    <select name="class" className="form-control" onChange={handleChange} >
                      <option value="">Select Class</option>
                      <option value="1">1</option>
                      <option value="2">2</option>
                      <option value="3">3</option>
                      <option value="4">4</option>
                      <option value="5">5</option>
                    </select>
                </Col>
                </Row>
                <Row>
                  <Col tabIndex="0" sm={6}>
                      <label for="subject" className="pt-1">Subject</label>
                      <select name="subject" className="form-control" onChange={handleChange} >
                        <option value="">Select Subject</option>
                        <option value="SST">SST</option>
                        <option value="Maths">Maths</option>
                        <option value="Physics">Physics</option>
                        <option value="Hindi">Hindi</option>
                        <option value="English">English</option>
                      </select>
                    
                  </Col> 
                  <Col tabIndex="0" sm={6}>
                    
                      <label  for="Type" className="pt-1">Type</label> 
                      <select name="type" className="form-control" onChange={handleChange} >
                        <option value="">Select Type</option>
                        <option value="Quiz">Quiz</option>
                        <option value="Exam">Exam</option>
                      </select>
                    
                  </Col> 
                </Row> 
                <Row>
                  <Col tabIndex="0" sm={6}>
                      <label  for="questions" aria-required="true" className="pt-1">No. of Question <span className="red">*</span></label> 
                      <select name="questions" className="form-control" onChange={handleChange} required >
                        <option value="">Select No. of Question</option>
                        <option value="5">5</option>
                        <option value="10">10</option>
                        <option value="15">15</option>
                        <option value="20">20</option>
                        <option value="25">25</option>
                        <option value="30">30</option>
                      </select>
                   
                  </Col>
                  <Col tabIndex="0" sm={6}>
                      <label for="attempt" aria-required="true" className="pt-1">No. of Attempt <span className="red">*</span></label> 
                      <select name="attempt" className="form-control" onChange={handleChange} required>
                          <option value="">Select No. of Attempt</option>
                          <option value="1">1</option>
                          <option value="2">2</option>
                          <option value="3">3</option>
                          <option value="4">4</option>
                          <option value="5">5</option>
                          <option value="6">6</option>
                          <option value="7">7</option>
                          <option value="8">8</option>
                          <option value="9">9</option>
                          <option value="10">10</option>
                      </select>
                  </Col>
                </Row>
                <Row>
                  <Col tabIndex="0" sm={6}>
                      <label  for="poolid" className="pt-1">PoolId</label>
                      <input type="text" name="poolid" className="form-control" value={formValues.poolid} autoComplete="off" onChange={handleChange}/>
                  </Col>
                  <Col tabIndex="0" sm={6}>
                        <label  for="overWrite" className="pt-1">Override</label> 
                        <select name="overWrite" className="form-control" onChange={handleChange} >
                            <option value="">Select Override</option>
                            <option value="Yes">Yes</option>
                            <option value="No">No</option>
                        </select>
                  </Col>
                </Row>
                <Row>
                  <Col tabIndex="0" sm={6}>
                      <label  for="marks" aria-required="true" className="pt-1">Score Per Question <span className="red">*</span></label>
                      <input type="text" name="marks" className="form-control" value={formValues.marks} autoComplete="off" onChange={handleChange} required />
                  </Col>
                  <Col tabIndex="0" sm={6}>
                    <label  for="marks" className="pt-1">Negative Marking</label> 
                    <select name="nagativeMarking" className="form-control" onChange={handleChange} >
                        <option value="">Select Negative Marking</option>
                        <option value="Yes">Yes</option>
                        <option value="No">No</option>
                    </select>
                  </Col>
                </Row>
                <Row>
                  <Col tabIndex="0" sm={6}>
                    <label  for="timelimit" aria-required="true" className="pt-1">Time Limit <span className="red">*</span></label> 
                    <select name="timelimit" className="form-control" onChange={handleChange} required>
                        <option value="">Select Time Limit</option>
                        <option value="60">60 Minute</option>
                        <option value="120">120 Minute</option>
                        <option value="180">180 Minute</option>
                    </select>
                  </Col>
                  <Col tabIndex="0" sm={6}>
                    <label  for="timelimit" aria-required="true" className="pt-1">Passing Threshold <span className="red">*</span></label> 
                    <select name="passingThreshold" className="form-control" onChange={handleChange} required>
                        <option value="">Select Passing Threshold</option>
                        <option value="30">30%</option>
                        <option value="40">40%</option>
                        <option value="50">50%</option>
                        <option value="60">60%</option>
                        <option value="70">70%</option>
                        <option value="80">80%</option>
                        <option value="90">90%</option>
                    </select>
                  </Col>
                </Row>
                <Row>
                  <Col>
                        <div role="button" style={{width:"100%",textAlign:"center"}}>
                        <button className="btn btn-result">Submit</button>
                        </div>
                  </Col>
                </Row>
              </Container>
            </div>
          </form>
        </div>
        <div
          className="modal left fade"
          id="exampleModal"
          tabindex="0"
          role="dialog"
          aria-labelledby="exampleModalLabel"
          aria-hidden="true"
        >
          <LeftPanel handlefontWeight={handlefontWeight} handlefontFamily={handlefontFamily} handleClick={handleClick} colorTheme={colorTheme}/>
        </div>
      </div>
    </div>
      
    </>
  );
};
export default AccessHelper;
