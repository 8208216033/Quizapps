import React from "react";
import "./App.css";
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import "../node_modules/bootstrap/dist/js/bootstrap.min.js";
import "./switcher.scss";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Start from "./Start";
import Home from "./Home";
import Result from "./Result";
import Registration from './Registration';
import AccessHelper from './AccessHelper'
function App() {
 
  
  return (
    <>
      <Router>
        <Routes>
          <Route exact path="/" element={<AccessHelper />} />
          <Route exact path="/home" element={<Home />} />
          <Route exact path="/start" element={<Start />} />
          <Route exact path="/result" element={<Result />} />
        </Routes>
      </Router>
    </>
  );
}

export default App;
