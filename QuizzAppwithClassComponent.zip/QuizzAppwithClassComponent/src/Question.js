export const QuizzData=[
    {
        id:0,
        question:"what is capital of india?",
        options:["delhi","mumbai","odisa","chennai"],
        answer:"delhi"
    },


    {
        id:1,
        question:"Ecology deals with?",
        options:["Birds","Cell formation","Relation between organisms and their environment","Tissues"],
        answer:"Relation between organisms and their environment"
    },

    {
        id:2,
        question:"Grand Central Terminal, Park Avenue, New York is the world's?",
        options:["largest railway station","highest railway station","longest railway station","None of the above"],
        answer:"largest railway station"
    },

    {
        id:3,
        question:"Entomology is the science that studies?",
        options:["Behavior of human beings","Insects","The origin and history of technical and scientific terms","The formation of rocks"],
        answer:"Insects"
    },

    {
        id:4,
        question:"Hitler party which came into power in 1933 is known as?",
        options:["Labour Party","Nazi Party","Ku-Klux-Klan","Democratic Party"],
        answer:"Nazi Party"
    }


]