import logo from './logo.svg';
 import './App.css';
import Quiz from './Quiz';

function App() {
  return (
    <div className="App">
     <Quiz/>
    </div>
  );
}

export default App;
